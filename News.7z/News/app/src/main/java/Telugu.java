import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.app.news.R;

public class Telugu extends Activity implements AdapterView.OnItemClickListener {

    /* Button button; */
    ListView listView;
    String ch[] = {"teNews 2013-09 Sep-Oct", "teNews 2013-07 Jul-Aug", "teNews 2013-05 May-Jun", "teNews 2013-03 Mar-Apr", "teNews 2013-01 Jan-Feb", "teNews 2012-11 Nov-Dec", "teNews 2012-09 Sep-Oct", "teNews 2012-07 Jul-Aug"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hrvatski);
        listView = (ListView) findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ch);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    private void goToUrl(String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (position == 0) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202013-09%20Sep-Oct.pdf");
        } else if (position == 1) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202013-07%20Jul-Aug.pdf");
        } else if (position == 2) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202013-05%20May-Jun.pdf");
        } else if (position == 3) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202013-01%20Jan-Feb.pdf");
        } else if (position == 4) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202012-11%20Nov-Dec.pdf");
        } else if (position == 5) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202012-11%20Nov-Dec.pdf");
        } else if (position == 6) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/telugu/teNews%202012-07%20Jul-Aug.pdf");
        }

    }
}