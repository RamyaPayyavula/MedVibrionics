import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.app.news.R;

public class Hindi extends Activity implements AdapterView.OnItemClickListener {

    /* Button button; */
    ListView listView;
    String ch[] ={"hnNews 2014-02 Feb SE","hnNews 2013-05 May-JUn"};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hrvatski);
        listView = (ListView) findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ch);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    private void goToUrl(String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (position == 0) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/hindi/hnNews%202014-02%20Feb%20SE.pdf");
        } else if (position == 1) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/hindi/hnNews%202014-02%20Feb%20SE.pdf");
        }

    }
}