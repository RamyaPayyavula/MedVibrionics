import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.app.news.R;

public class Spanish extends Activity implements AdapterView.OnItemClickListener {

    /* Button button; */
    ListView listView;
    String ch[] ={"spNews 2014-09 Sep-Oct","spNews 2014-07 Jul-Aug","spNews 2014-05 May-Jun","spNews 2014-03 Mar-Apr","spNews 2014-02 Feb SE","spNews 2014-01 Jan-Feb","spNews 2013-11 Nov-Dec","spNews 2013-09 Sep-Oct","spNews 2013-07 Jul-Aug","spNews 2013-05 May-Jun","spNews 2013-03 Mar-Apr","spNews 2013-01 Jan-Feb","spNews 2012-11 Nov-Dec","spNews 2012-09 Sep-Oct","spNews 2012-07 Jul-Aug","spNews 2012-05 May-Jun","spNews 2012-03 Mar-Apr","spNews 2012-01 Jan-Feb","spNews 2011-11 Nov-Dec","spNews 2011-09 Sep-Oct","spNews 2011-07 Jul-Aug","spNews 2011-05 May-Jun","spNews 2011-04.5 Apr SE","spNews 2011-03 Mar-Apr","spNews 2011-01 Jan-Feb","spNews 2010-11 Nov-Dec","spNews 2010-09 Sep-Oct"};
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.hrvatski);
        listView = (ListView) findViewById(R.id.listview);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, ch);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }


    private void goToUrl(String url) {
        Uri uriUrl = Uri.parse(url);
        Intent launchBrowser = new Intent(Intent.ACTION_VIEW, uriUrl);
        startActivity(launchBrowser);
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        if (position == 0) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-09%20Sep-Oct.pdf");
        } else if (position == 1) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-07%20Jul-Aug.pdf");
        } else if (position == 2) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-05%20May-Jun.pdf");
        } else if (position == 3) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-03%20Mar-Apr.pdf");
        } else if (position == 4) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-02%20Feb%20SE.pdf");
        } else if (position == 5) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202014-01%20Jan-Feb.pdf");
        } else if (position == 6) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-11%20Nov-Dec.pdf");
        } else if (position == 7) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-09%20Sep-Oct.pdf");
        } else if (position == 8) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-07%20Jul-Aug.pdf");
        } else if (position == 9) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-05%20May-Jun.pdf");
        } else if (position == 10) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-03%20Mar-Apr.pdf");
        } else if (position == 11) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202013-01%20Jan-Feb.pdf");
        } else if (position == 12) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-11%20Nov-Dec.pdf");
        } else if (position == 13) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-09%20Sep-Oct.pdf");
        } else if (position == 14) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-07%20Jul-Aug.pdf");
        } else if (position == 15) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-05%20May-Jun.pdf");
        } else if (position == 16) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-03%20Mar-Apr.pdf");
        } else if (position == 17) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202012-01%20Jan-Feb.pdf");
        } else if (position == 18) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-11%20Nov-Dec.pdf");
        } else if (position == 19) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-09%20Sep-Oct.pdf");
        } else if (position == 20) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-07%20Jul-Aug.pdf");
        } else if (position == 21) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-05%20May-Jun.pdf");
        } else if (position == 22) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-04.5%20Apr%20SE.pdf");
        } else if (position == 23) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-03%20Mar-Apr.pdf");
        } else if (position == 24) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202011-01%20Jan-Feb.pdf");
        } else if (position == 25) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202010-11%20Nov-Dec.pdf");
        } else if (position == 26) {
            goToUrl("http://www.vibrionics.org/jvibro/newsletters/spanish/spNews%202010-09%20Sep-Oct.pdf");
        }

    }
}