package com.app.spinners;

import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
/*import android.view.Menu;*/
/*import android.view.MenuItem;*/
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
/*import android.widget.SpinnerAdapter;*/
import android.widget.TextView;
import android.widget.Toast;
/*import static com.app.spinners.R.array.*;*/



public class MainActivity extends ActionBarActivity implements AdapterView.OnItemSelectedListener{
     Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        spinner= (Spinner) findViewById(R.id.spinner);
        ArrayAdapter adapter=ArrayAdapter.createFromResource(this,R.array.Medical,android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        TextView myText=(TextView)view;
        Toast.makeText(this, "you selected" + myText.getText(), Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
