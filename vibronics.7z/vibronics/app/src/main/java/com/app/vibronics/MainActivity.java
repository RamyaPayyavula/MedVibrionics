package com.app.vibronics;

import android.content.Context;
import android.content.res.Resources;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {
    ListView list;
    String[] htitles;
    String[] hdescription;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Resources res = getResources();
        htitles=res.getStringArray(R.array.titles);
        hdescription =res.getStringArray(R.array.descriptions);
        list =(ListView)findViewById(R.id.listView);
        VivzAdapter adapter=new VivzAdapter(this,htitles,hdescription);
        list.setAdapter(adapter);
    }
 }
class VivzAdapter extends ArrayAdapter<String>
{
    Context context;
    String[] titleArray;
    String[] descriptionArray;
    VivzAdapter(Context c,String[] titles,String[] desc)
    {
        super(c,R.layout.single_row,R.id.textView,titles);
        this.context=c;
        this.titleArray=titles;
        this.descriptionArray=desc;
    }
    public View getView(int position,View convertView,ViewGroup parent)
    {
        LayoutInflater inflator= (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View row=inflator.inflate(R.layout.single_row,parent,false);
        TextView mytitles=(TextView)row.findViewById(R.id.textView);
        TextView mydescriptions= (TextView) row.findViewById(R.id.textView2);
        mytitles.setText(titleArray[position]);
        mydescriptions.setText(descriptionArray[position]);


        return row;
    }

}
